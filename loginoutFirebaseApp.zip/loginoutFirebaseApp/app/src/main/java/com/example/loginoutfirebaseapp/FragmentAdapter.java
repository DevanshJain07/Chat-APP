package com.example.loginoutfirebaseapp;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class FragmentAdapter extends FragmentPagerAdapter {
public FragmentAdapter(FragmentManager manager){super(manager);}
public int getCount(){ return 3;}

    @NonNull
    @Override
    public Fragment getItem(int position) {
        Fragment page=null;
    switch (position){
        case 0: page=new ChatMessageFragment.newInstance("One","Two");
        case 1: page=HistoryFragment.newInstance(1);break;
        case 2: page=MembersFragment.newInstance(2);break;
        default: page=ChatMessageFragment.newInstance("One","Two");break;


    }
    page=new ChatMessageFragment.newInstance("One","Two");
    return page;
    }
}
