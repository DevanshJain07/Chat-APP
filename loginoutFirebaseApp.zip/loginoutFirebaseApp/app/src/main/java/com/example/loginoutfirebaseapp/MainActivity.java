package com.example.loginoutfirebaseapp;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.widget.TextView;

import com.example.loginoutfirebaseapp.dummy.DummyContent;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
public class MainActivity extends AppCompatActivity implements ChatMessageFragment.OnFragmentInteractionListener,HistoryFragment.OnListFragmentInteractionListener,MembersFragment.OnListFragmentInteractionListener {
    final String TAG = "FirebaseTest";
    FirebaseApp mApp;
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;
    String mDisplayName;
    TextView mScreenMessage;
    ViewPager mViewPager = null;
    FragmentAdapter mFragmentAdapter;
    private Menu menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initFirebase();
        initViewPager();
    }

    private void initFirebase() {
        mApp = FirebaseApp.getInstance();
        mAuth = FirebaseAuth.getInstance(mApp);
//            mScreenMessage = (TextView)findViewById(R.id.textView);
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = mAuth.getCurrentUser();
                if (user != null) {
                    Log.e(TAG, "AUTH STATE UPDATE : Valid user logged in [" + user.getEmail() + "] [" + user.getDisplayName() + "]");
                    String displayName = user.getDisplayName().toString();
                    mScreenMessage.setText("User : " + displayName);
                    if (displayName != null)
                        mDisplayName = displayName;
                    else
                        mDisplayName = "Unknown DisplayName";
                } else {
                    Log.e(TAG, "AUTH STATE UPDATE : NO valid user logged in");
                    mDisplayName = "No Valid User";
                    mAuth.removeAuthStateListener(mAuthListener);
                    Intent signInIntent = new Intent(getApplicationContext(), SignIn.class);
                    startActivityForResult(signInIntent, 101);
                }
            }
        };
        mAuth.addAuthStateListener(mAuthListener);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e(TAG, "Activity returned");
        if (resultCode == RESULT_OK) {
            if (requestCode == 101) {
                mDisplayName = data.getStringExtra("displayname");
                Log.e(TAG, "Intent returned Display Name [" + mDisplayName + "]");
                mAuth.addAuthStateListener(mAuthListener);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.menu = menu;
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.options_logout) {
            Log.e(TAG, "Logout selected");
            mAuth.signOut();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void initViewPager() {
        mViewPager = (ViewPager) findViewById(R.id.ViewPager);
        mViewPager.setAdapter(mFragmentAdapter);
    }

    public void onFragmentInteraction(Uri uri) {
        Log.e(TAG, "Chat Fragment");
    }

    public void onHistoryListFragmentInteraction(DummyContent.DummyItem item) {
Log.e(TAG,"History Fragment");
    }
    public void onMembersListFragmentInteraction(DummyContent.DummyItem item){
        Log.e(TAG,"Members Fragment");

    }

}